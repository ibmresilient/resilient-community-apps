#!/usr/bin/env python
# -*- coding: utf-8 -*-
# (c) Copyright IBM Corp. 2010, 2020. All Rights Reserved.

""" TODO: implement clone """

import logging

# Get the same logger object that is used in app.py
LOG = logging.getLogger("resilient_sdk_log")
