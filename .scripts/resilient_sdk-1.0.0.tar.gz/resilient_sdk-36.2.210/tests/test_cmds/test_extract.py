#!/usr/bin/env python
# -*- coding: utf-8 -*-
# (c) Copyright IBM Corp. 2010, 2020. All Rights Reserved.

from resilient_sdk.cmds import CmdExtract


def test_cmd_extract_setup(fx_get_sub_parser, fx_cmd_line_args_docgen):
    # TODO
    pass


def test_execute_command():
    # TODO
    pass