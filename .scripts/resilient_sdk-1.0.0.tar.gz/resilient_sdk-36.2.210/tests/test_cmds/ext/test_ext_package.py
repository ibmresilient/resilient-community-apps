#!/usr/bin/env python
# -*- coding: utf-8 -*-
# (c) Copyright IBM Corp. 2010, 2020. All Rights Reserved.

from resilient_sdk.cmds import CmdExtPackage


def test_setup():
    # TODO
    pass


def test_execute_command():
    # TODO
    pass