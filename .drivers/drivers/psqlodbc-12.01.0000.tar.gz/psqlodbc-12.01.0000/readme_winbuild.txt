This folder contains 4 batch scripts
	BuildAll.bat
	editConfiguration.bat
	regress.bat
	buildInstallers.bat
which have the same functionalities as corresponding powershell scripts in
winbuild folder.

See docs\win32-compilation.html and winbuild\readme.txt for Windows compilation instructions.

For info on building installers, see installer\README.txt
